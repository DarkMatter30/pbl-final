<h1>Animated Login Page</h1>
So basically, at the very first we are supposed to design a box and let us name it box-form. So in that box-form we made two parts- left and the right.
In the left part we are supposed to add a background image which will be added through css i.e.  the stylesheet and then the text is written on the top of it. So a different class named 'overlay' is to be created using HTML and then the text and the social media buttons are added to it.
In the same way if the right part of the box-form is written then it would include the input types for username and password along with the checkbox of remember me and a multicolored button with login option.
So, for the animated part linear-gradient is used to set linear gradient at the background image and the background-position is adjusted accordingly.
